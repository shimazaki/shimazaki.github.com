# functions for RSTP written by K. Katahira

plot.barpoints <- function (value, group = NULL, matched = FALSE) {
  
  # extract levels (group)
  l <- levels(group)
  
  xbar <- barplot(tapply(value, group, mean), space = 0.1,
          width = 0.9, ylab="value",ylim=c(0,max(value)+1.0), 
          names = l)
  
  for (idxg in 1:length(l)) {
    x <- value[group==l[idxg]]
    
    # connect the matched samples
    for (idx in 1:length(x)) {
      if (matched == T && idxg > 1) {
        lines(c(xbar[idxg-1],xbar[idxg]),c(x_pre[idx],x[idx]))
      }
      points(xbar[idxg],x[idx])
    }
    x_pre <- x
  }
}
