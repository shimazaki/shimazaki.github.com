# R commands for Statistical analysis of behaviors I 
# by Kentaro Katahira - kkatahir@gmail.com
# Please consult Hideaki Shimazaki (shimazaki@brain.riken.jp) for 2014 lecture.

# clear all variables
rm(list=ls())

# Set workng directroy 
# Specify a path to the directory in which the script file is.
# Replace the path in the following command with your own path.
setwd("/Users/hideaki/Dropbox/15/lecture/1512_riken_statistics/scripts")
# check the current working directory
getwd()


# ---------------------------#
# Basics of R                #
# ---------------------------#
# You can run the code in a current line by Ctrl+Enter (Win) or Command+Return (Mac). 

# (1) simple arithmetic calculation

1 + 2
5 - 3
3 * 2
10 / 2
10^3
(3^2 + 3*2)/2

# (2) using variables 

a <- 2
a
b <- 3
a + b
a / b
c <- a * b
c
c^2

# (3) using simple functions

sqrt(16)
sin(pi/2)
exp(1)
log(exp(1))
date()

# (4) see help 

?date

# (5) vector

y <- c(3,7,9,11) # "c" stands for combine or concatenate
y
y[2] # access the second elements of y
y[c(2,4)] 


# ------------------------------#
# Simulation of data generation #
# ------------------------------#
  
# (6) generate normal random variable 

x <- rnorm(100)

# plot x
hist(x,freq = FALSE,col="gray")
rug(x)

# draw density function of normal distribution
xvals <- seq(-4,4,0.01)
lines(xvals,dnorm(xvals), type="l",col="blue", lwd=2)

# Exercise : 
# Change the number of samples from 100 (e.g., 1000, 10000...etc) and check the histgram. 

# clean the figure
frame()

# (7) generating two groups data

x1 <- rnorm(10, mean = 2, sd = 1)
x2 <- rnorm(10, mean = 2, sd = 1)

# check the mean 
mean(x1)
mean(x2)

# plot mean 
xbar <- barplot(c(mean(x1),mean(x2)), space = 0.1,
        width = 0.9, xlab="group",ylab="value",xlim=c(0,2), ylim=c(0,5))

# plot indivisual samples
points((c(rep(xbar[1],10),rep(xbar[2],10))),c(x1,x2))


# (8) Perform t-test

t.test(x1,x2, var.equal=T)


# (9) Verify the p-value by simulation

N <- 10000 # number of simulation trials
n <- 10 # number of subjects in each group

plog <- numeric(N) 
tlog <-  numeric(N) 
for (idx in 1:N) {
  # generate sample
  x1 <- rnorm(n, mean = 2, sd = 1)
  x2 <- rnorm(n, mean = 2, sd = 1)
  # perform t-test
  results <- t.test(x1,x2, var.equal=T)
  # record the result
  plog[idx] <- results$p.value
  tlog[idx] <- results$statistic 
}
# show the fraction of trials detected as significant
sum(plog < 0.05)/N 

# show the distribution of test statistic (t)
hist(tlog,freq=FALSE, breaks=40,col="gray")
rug(tlog)

# draw density function of Students't distribution
xvals <- seq(min(tlog),max(tlog),0.01)
lines(xvals,dt(xvals,df=2*(n-1)), type="l",col="blue", lwd=2)

# Exercise : 
# Change n (the number of subjects) (e.g., 3, 10000...etc) 

# ------------------------------#
# (11) Create dataframe 1
# ------------------------------#

# Create dataframe 1
sex    <- c("F","F","M","M","M")
height <- c(158,162,177,173,166)
weight <- c(51,55,72,57,64)
data <- data.frame(SEX=sex, HEIGHT=height, WEIGHT=weight)

# check the data frame
data

# Create dataframe 2

x1 <- rnorm(10, mean = 2, sd = 1)
x2 <- rnorm(10, mean = 2, sd = 1)
X <- data.frame(group=gl(2,10,labels = c("Control", "Treated")), values = c(x1,x2))
# To check what is "gl" , put  ?gl

# check the data frame
X

# compute mean for each group
tapply(X$values, X$group, mean)

# this will produce the identical resut with 
# t.test(x1,x2, var.equal=T)
t.test(values~group, data=X, var.equal=T)

# ------------------------------#
# (12) Read data from files          
# ------------------------------#

# [Read from clipboard]
# 1): Copy the data from Excel or text file
# 2): Read data from clipboard 
data1 <- read.table("clipboard", header = T)

# Tip: Hit the up arrow to get the previous command. 
# First copy and paste above command to R console, then 
# copy the date to clipboard (by Ctrl+C), then hit the up arrow. 

# Read data from text file 
data1 <- read.table("data1_twosample.txt", header = T)

# Read data from csv 
data1 <- read.csv("data1_twosample.csv", header = T)

# If you want to read the data from excell file directly, try this: 
# install.packages("xlsx", dep=T) # if necessary
# library(xlsx)
# x <- read.xlsx("data1_twosample.xlsx", sheetName="sheet1")

# (13) perform unpaired t-test
t.test(value~group, data=data1, var.equal=T)


# ------------------------------#
# (14) paired t-test
# ------------------------------#

# Read data from text file 
data2 <- read.table("data2_twosample_paird.txt", header = T)

# plot data
x1 <- data2$value[data2$condition=="control"]
x2 <- data2$value[data2$condition=="treated"]
xbar <- barplot(c(mean(x1),mean(x2)), space = 0.1,
        width = 0.9, xlab="group",ylab="value",ylim=c(0,max(c(x1,x2))+1.0), 
                names = c("control","treated"))
# connect the matched samples
for (idx in 1:length(x1)) {
  lines(c(xbar[1],xbar[2]),c(x1[idx],x2[idx]))
  points(xbar[1],x1[idx])
  points(xbar[2],x2[idx])
}

# paired t-test
t.test(value~condition, data = data2, var.equal=T, paired=T)

# unpaired t-test
t.test(value~condition, data = data2, var.equal=T, paired=F)

# difference between conditions
d <- data2$value[data2$condition == "treated"] - data2$value[data2$condition == "control"]
# One Sample t-test
t.test(d)

# repeated measeres ANOVA (just confirm this will produce the same result)
aovresult <- aov(value~condition + Error(subjects/condition), data=data2)
summary(aovresult)

# ------------------------------#
# (15) one-way ANOVA
# ------------------------------#

# Read data from text file 
data3 <- read.table("data3_one_way_anova.txt", header = T)

barplot(tapply(data3$value, data3$group, mean))

# one-way ANOVA
aovresult <- aov(value~group, data=data3)
summary(aovresult)

# ------------------------------#
# (16) one-way ANOVA with repeated measures
# ------------------------------#

# Read data from text file 
data4 <- read.table("data4_RM_one_way_anova.txt", header = T)

barplot(tapply(data4$value, data4$condition, mean))

# one-way ANOVA with repeated measeres
aovresult <- aov(value~condition + Error(subjects/condition), data=data4)
summary(aovresult)

# one-way ANOVA ( without repeated measeres; incorrect use )
aovresult <- aov(value~condition, data=data4)
summary(aovresult)


# --------------------------------------------#
# (17) Two-way ANOVA (no matching)
# --------------------------------------------#
data6 <- read.table("data6_two_way_ANOVA_no_matching.txt", header = T)

# display data
boxplot(value~ condition, data = data6[data6$gender=="male",],ylim=c(-5,5),boxwex=.1,col="red",outline=FALSE)
par(new = TRUE)   
boxplot(value~ condition, data = data6[data6$gender=="female",],ylim=c(-5,5),boxwex=.1, col="blue", outline=FALSE)

# two-way ANOVA ( without repeated measeres )
aovresult <- aov(value~gender*condition, data = data6)
summary(aovresult)

# Equivalent statement (gender*condition expands to gender + condition +  gender*condition)
aovresult <- aov(value~ gender + condition +  gender*condition, data = data6)
summary(aovresult)

# plot means
interaction.plot(data6$condition, data6$gender, data6$value, type="b",col=c("red","blue"), pch=c(16,18))


# --------------------------------------------#
# (18) Two-way ANOVA (no matching)
# --------------------------------------------#
data7 <- read.table("data6_two_way_ANOVA_no_matching_interaction.txt", header = T)

# two-way ANOVA ( without repeated measeres )
aovresult <- aov(value~gender*condition, data = data7)
summary(aovresult)

# Equivalent statement (gender*condition expands to gender + condition +  gender*condition)
aovresult <- aov(value~ gender + condition +  gender*condition, data = data7)
summary(aovresult)

# plot means
interaction.plot(data6$condition, data6$gender, data6$value, type="b",col=c("red","blue"), pch=c(16,18))

# --------------------------------------------#
# (19) Post-hoc anlaysis (no matching)
# --------------------------------------------#

## Tukey Honest Significant Differences (TukeyHSD) 
TukeyHSD(aov(value~condition,data = data6))

# Download and install packages
install.packages("multcomp") ## Need to specify CRAN the 1st time

# Load package
library(multcomp)

## Dunett's method (Only for comparing treatment means vs. control mean)
test.dunnett <- glht(aovresult,linfct=mcp(condition="Dunnett"))
summary(test.dunnett)

## Tukey's method (this will reproduce the results of TukeyHSD(aovresult))
test.tukey <- glht(aovresult,linfct=mcp(condition="Tukey"))
summary(test.tukey)







